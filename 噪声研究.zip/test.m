clear
clc
close all

a = 0;    %��˹������ֵ
b = 0.08; %��˹������׼��

num = 200;

t = 1:200;

gaussian = a + b .* randn(1, num);
gaussian = sort(gaussian);
figure, plot(gaussian, 'bo', 'MarkerFaceColor', 'b')
hold on
p1 = 0.001356;
p2 = -0.1406;
plot(t, p1*t+p2, 'r-')
hold off

a_6 = sort(randraw('tukeylambda', -0.06, [1, 200]));
figure, plot(a_6, 'bo', 'MarkerFaceColor', 'b')
p1 = 0.0334;
p2 = -3.514;
hold on
plot(t, p1*t+p2, 'r-')
hold off

a_26 = sort(randraw('tukeylambda', -0.26, [1, 200]));
figure, plot(a_26, 'bo', 'MarkerFaceColor', 'b')
p1 = 0.04336;
p2 = -4.65;
hold on
plot(t, p1*t+p2, 'r-')
hold off